// Fig. 6.11: TimeTest.java
// Chaining method calls together with the this reference
import javax.swing.border.EmptyBorder;
import javax.swing.*;
import java.awt.*;

public class TimeTest extends JFrame {
   private Time t;
   private JPanel contentPane;

   public TimeTest() {
       t = new Time();
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       setBounds(100, 100, 300, 450);
       contentPane = new JPanel();
       contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
       setContentPane(contentPane);
       contentPane.setLayout(null);    
   }

   public void paint( Graphics g )
   {
      super.paint(g);
      //t.setTime(18,30,22);
      t.setHour( 18 ).setMinute( 30 ).setSecond( 22 );
      g.drawString( "Hora militar: ................." + 
                    t.toMilitaryString(), 25, 40 );
      g.drawString( "Hora estándar: " + t.toString(),
                    25, 65 );
      
      g.drawString( "Nueva hora estándar: " + 
         t.setTime( 20, 20, 20 ).toString(), 25, 100 );      
   }
   public static void main(String [] args) { 
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    TimeTest frame = new TimeTest();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
  }


}



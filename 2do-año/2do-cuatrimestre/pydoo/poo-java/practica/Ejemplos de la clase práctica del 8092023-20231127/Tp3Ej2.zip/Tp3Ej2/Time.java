
// Definición de la Clase Time
public class Time {
   private int hour;     // 0 - 23
   private int minute;   // 0 - 59
   private int second;   // 0 - 59


   // El constructor de la clase Time inicializa cada variable de instancia
   // en cero. Esto asegura que el objeto Time inicia
   // en un estado consistente.
   public Time() { setTime( 0, 0, 0 ); }

   // Constructor de Time : hora provista, minutos y segundos
   // son 0 por omisión.
   public Time( int h ) { setTime( h, 0, 0 ); }

   // Constructor de Time: hora y minutos provistos, segundos
   // son 0 por omisión.
   public Time( int h, int m ) { setTime( h, m, 0 ); }

   // Constructor de Time: hora, minutos and segundos provistos.
   public Time( int h, int m, int s ) { setTime( h, m, s ); }

   // Métodos de Seteo
   // Fijar un nuevo valor de Time usando hora militar. Realizar
   // validaciones sobre los datos. Asignar cero a los  
   // valores no válidos.
   public Time setTime( int h, int m, int s )
   {
      setHour( h );    // setea la hora
      setMinute( m );  // setea los minutos
      setSecond( s );  // setea los segundos

      return this;     // permite el encadenamiento
   }

   // setea la hora
   public Time setHour( int h ) 
   { 
      hour = ( ( h >= 0 && h < 24 ) ? h : 0 ); 

      return this;     // permite el encadenamiento
   }

   // setea los minutos 
   public Time setMinute( int m ) 
   { 
      minute = ( ( m >= 0 && m < 60 ) ? m : 0 ); 

      return this;     // permite el encadenamiento
   }

   // setea los segundos
   public Time setSecond( int s ) 
   { 
      second = ( ( s >= 0 && s < 60 ) ? s : 0 ); 

      return this;     // permite el encadenamiento
   }

   // Métodos Get
   // obtiene la hora
   public int getHour() { return hour; }

   // obtiene los minutos
   public int getMinute() { return minute; }

   // obtiene los segundos
   public int getSecond() { return second; }

   // Convertir Time en un String en formato militar
   public String toMilitaryString()
   {
      return ( hour < 10 ? "0" : "" ) + hour +
             ( minute < 10 ? "0" : "" ) + minute;
   }

   // Convertir Time en un String en formato de hora estándar
   public String toString()
   {
      return ( ( hour == 12 || hour == 0 ) ? 12 : hour % 12 ) +
             ":" + ( minute < 10 ? "0" : "" ) + minute +
             ":" + ( second < 10 ? "0" : "" ) + second +
             ( hour < 12 ? " AM" : " PM" );
   }
}

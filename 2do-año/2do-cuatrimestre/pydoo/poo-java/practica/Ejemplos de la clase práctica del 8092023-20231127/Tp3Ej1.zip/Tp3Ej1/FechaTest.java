import javax.swing.border.EmptyBorder;
import javax.swing.*;
import java.awt.*;

public class FechaTest extends JFrame {
   private Fecha f1,f2;
   private JPanel contentPane;

   public FechaTest() {
       f1 = new Fecha(23,12,2010);
       f2 = new Fecha("12/05/2001");
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       setBounds(100, 100, 300, 450);
       contentPane = new JPanel();
       contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
       setContentPane(contentPane);
       contentPane.setLayout(null);    
   }

   public void paint( Graphics g )
   {
      super.paint(g);
      g.drawString( "Fecha 1: ................." + 
                    f1.FechaStr(), 25, 50 );
      g.drawString( "Fecha 2: ................." + f2.FechaStr(),
                    25, 100 );
      
      }
   public static void main(String [] args) { 
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    FechaTest frame = new FechaTest();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
  }


}


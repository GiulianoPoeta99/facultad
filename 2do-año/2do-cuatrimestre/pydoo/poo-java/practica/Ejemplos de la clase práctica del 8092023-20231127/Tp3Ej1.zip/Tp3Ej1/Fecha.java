
/**
 * Write a description of class Fecha here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Fecha
{
    // instance variables
    private int dia,mes,anio;

    /**
     * Constructor for objects of class Fecha
     */
    public Fecha(int d, int m, int a)
    {
        // validamos los datos recibidos
        // validamos 1° el mes, luego el dia segun el mes que sea
        // por ultimo si el anio es bisiesto tener en cuenta para febrero
        
        dia=d;
        mes=m;
        anio = a;
    }
    
    public Fecha(String fechaStr)  // "25/04/2008"
    {
        int d = Integer.valueOf(fechaStr.substring(0, 2));
        int m = Integer.valueOf(fechaStr.substring(3, 5));
        int a = Integer.valueOf(fechaStr.substring(6));
        // validamos los datos recibidos
        // validamos 1° el mes, luego el dia segun el mes que sea
        // por ultimo si el anio es bisiesto tener en cuenta para febrero

        dia=d;
        mes=m;
        anio = a;
    
    }
    

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public String FechaStr()
    {
        return ""+dia+"/"+mes+"/"+ anio;
    }
}

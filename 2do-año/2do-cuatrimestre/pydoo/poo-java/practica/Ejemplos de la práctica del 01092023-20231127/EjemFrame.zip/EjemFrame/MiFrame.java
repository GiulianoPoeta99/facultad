
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MiFrame extends JFrame
{
    JLabel lH,lM,lS;
    JTextField jtfH,jtfM,jtfS,resultado;
    JButton boton;
    public MiFrame()
    {
        
        lM=new JLabel("Minutos:");
        lH=new JLabel("Hora:");
        lS=new JLabel("Segundos:");
        jtfH=new JTextField(2);
        jtfM=new JTextField(2);
        jtfS=new JTextField(2);
        resultado=new JTextField(20);
        boton=new JButton("Aceptar");
        Container cp=getContentPane();
        cp.setLayout(new FlowLayout());
        cp.add(lH);
        cp.add(jtfH);
        cp.add(lM);
        cp.add(jtfM);
        cp.add(lS);
        cp.add(jtfS);
        cp.add(boton);
        cp.add(resultado);
        boton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            { int h=Integer.parseInt(jtfH.getText());
                //completar
              resultado.setText(""+h);  
            }
        });
        
    }
    public static void main(String[] args)
    { MiFrame m=new MiFrame();
      m.setSize(400,500);
      m.setVisible(true);  
    }
}


/**
 * Write a description of class TimeTest2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

// Clase TimeTest para probar la clase Time
public class TimeTest2 extends JFrame
{
   private Time t;
   private JPanel contentPane;

   public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    TimeTest2 frame = new TimeTest2();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
   }
   
   public TimeTest2() {
       t = new Time();
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       setBounds(100, 100, 450, 300);
       contentPane = new JPanel();
       contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
       setContentPane(contentPane);
       contentPane.setLayout(null);    
   }

   public void paint( Graphics g )
   {
      super.paint(g);
      g.drawString( "La hora militar inicial es: " + 
                    t.toMilitaryString(), 25, 25 );
      g.drawString( "La hora estandar inicial es: " +
                    t.toString(), 25, 40 );

      t.setTime( 13, 27, 6 );
      g.drawString( "Hora militar despues de setTIme: " + 
                    t.toMilitaryString(), 25, 70 );
      g.drawString( "Hora estandar despues de setTime: " +
                    t.toString(), 25, 85 );

      t.setTime( 99, 99, 99 );
      g.drawString( "Despues de intentar un seteo invalido:",
                    25, 115 ); 
      g.drawString( "Hora Militar: " + 
                    t.toMilitaryString(), 25, 130 );
      g.drawString( "Hora Standard: " + t.toString(), 
                    25, 145 );
   }
 


}


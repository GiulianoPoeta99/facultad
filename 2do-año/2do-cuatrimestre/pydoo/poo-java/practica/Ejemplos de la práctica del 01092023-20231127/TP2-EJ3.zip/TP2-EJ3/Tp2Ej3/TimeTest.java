// Clase TimeTest para probar la clase Time

import java.applet.Applet;
import javax.swing.*;
import java.awt.*;

public class TimeTest extends JApplet {
   private Time t;

   public void init()
   {
      t = new Time();
      getContentPane().add(new JLabel("Applet!!!"));
   }
   public void start() { 
    }
   public void stop() { 
    }
   public void destroy() { 
    }
   
    public void paint( Graphics g )
   {
      super.paint(g);
       g.drawString( "La hora militar inicial es: " + 
                    t.toMilitaryString(), 25, 25 );
      g.drawString( "La hora estandar inicial es: " +
                    t.toString(), 25, 40 );

      t.setTime( 13, 27, 6 );
      g.drawString( "Hora militar despues de setTIme: " + 
                    t.toMilitaryString(), 25, 70 );
      g.drawString( "Hora estandar despues de setTime: " +
                    t.toString(), 25, 85 );

      t.setTime( 99, 99, 99 );
      g.drawString( "Despues de intentar un seteo invalido:",
                    25, 115 ); 
      g.drawString( "Hora Militar: " + 
                    t.toMilitaryString(), 25, 130 );
      g.drawString( "Hora Standard: " + t.toString(), 
                    25, 145 );
   }
 
   public static void main(String [] args) { 
    //crear un objeto f de la clase JFrame 
    JFrame f = new JFrame("Testeo Clase Time"); 

    //crear una instancia de TestApplet 
    TimeTest ta = new TimeTest(); 

    //añadir la instancia del applet al marco 
    f.getContentPane().setLayout(new BorderLayout()); 
    f.getContentPane().add("Center", ta); 

    //inicializar las variables al ancho y el alto de la tag <applet> 
    int width = 400; 
    int height = 400; 
    f.setSize(width, height); 

    //llamar a init() y a start() si es necesario 
    ta.init(); 
    ta.start(); 

    //hacer visible el marco 
    f.setVisible(true); 
  }


}


// Definicion Clase Time
public class Time {
   private int hour;     // 0 - 23
   private int minute;   // 0 - 59
   private int second;   // 0 - 59

   // El constructor de la clase Time inicializa cada variable de instancia
   // en cero. Esto asegura que el objeto Time inicia
   // en un estado consistente.
   public Time() { setTime( 0, 0, 0 ); }

   // Fijar un nuevo valor de Time usando hora militar. Realizar
   // validaciones sobre los datos. Asignar cero a los  
   // valores no válidos.
   public void setTime( int h, int m, int s )
   {
      hour = ( ( h >= 0 && h < 24 ) ? h : 0 );
      minute = ( ( m >= 0 && m < 60 ) ? m : 0 );
      second = ( ( s >= 0 && s < 60 ) ? s : 0 );
   }

   // Convertir Time en un String en formato militar
   public String toMilitaryString()
   {
      return ( hour < 10 ? "0" : "" ) + hour +
             ( minute < 10 ? "0" : "" ) + minute;
   }

   // Convertir Time en un String en formato de hora estándar
   public String toString()
   {
      return ( ( hour == 12 || hour == 0 ) ? 12 : hour % 12 ) +
             ":" + ( minute < 10 ? "0" : "" ) + minute +
             ":" + ( second < 10 ? "0" : "" ) + second +
             ( hour < 12 ? " AM" : " PM" );
   }
}

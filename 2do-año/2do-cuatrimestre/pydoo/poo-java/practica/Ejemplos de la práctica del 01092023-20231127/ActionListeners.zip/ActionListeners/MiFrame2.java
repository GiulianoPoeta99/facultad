import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MiFrame2 extends JFrame
{
    JButton boton;
    JTextField texto;
    
    public MiFrame2()
    {
        setSize(200,100);
        boton=new JButton("OK");
        texto=new JTextField(10);
        Container cp=getContentPane();
        cp.setLayout(new FlowLayout());
        cp.add(boton);
        cp.add(texto);
        boton.addActionListener(new BotonActionListener());
        
    }
    
    public static void main(String[] args)
    {
        MiFrame2 mf=new MiFrame2();
        mf.setVisible(true);
    }
    
    private class BotonActionListener implements ActionListener
    {
        public void actionPerformed(ActionEvent evt)
        { texto.setText("Accion2!!");
        }
    }
    
    
}

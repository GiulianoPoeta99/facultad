import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MiFrame3 extends JFrame
{
    JButton boton;
    JTextField texto;
    
    public MiFrame3()
    {
        setSize(200,100);
        boton=new JButton("OK");
        texto=new JTextField(10);
        Container cp=getContentPane();
        cp.setLayout(new FlowLayout());
        cp.add(boton);
        cp.add(texto);
        boton.addActionListener(new ActionListener()
        { public void actionPerformed(ActionEvent evt)
          { texto.setText("Accion3!!");
          }
        });
        
    }
    
    public static void main(String[] args)
    {
        MiFrame3 mf=new MiFrame3();
        mf.setVisible(true);
    }
    
    
}

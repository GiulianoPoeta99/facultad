import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MiFrame4 extends JFrame
{
    JButton boton;
    JTextField texto;
    
    public MiFrame4()
    {
        setSize(200,100);
        boton=new JButton("OK");
        texto=new JTextField(10);
        Container cp=getContentPane();
        cp.setLayout(new FlowLayout());
        cp.add(boton);
        cp.add(texto);
        boton.addActionListener(evt->
         texto.setText("Accion4!!"));
        
    }
    
    public static void main(String[] args)
    {
        MiFrame4 mf=new MiFrame4();
        mf.setVisible(true);
    }
    
    
}

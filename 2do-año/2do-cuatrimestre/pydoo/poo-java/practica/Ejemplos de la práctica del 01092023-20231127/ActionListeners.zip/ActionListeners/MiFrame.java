import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MiFrame extends JFrame
{
    JButton boton;
    JTextField texto;
    
    public MiFrame()
    {
        setSize(200,100);
        boton=new JButton("OK");
        texto=new JTextField(10);
        Container cp=getContentPane();
        cp.setLayout(new FlowLayout());
        cp.add(boton);
        cp.add(texto);
        BotonActionListener bal=new BotonActionListener();
        boton.addActionListener(bal);
        
    }
    
    public static void main(String[] args)
    {
        MiFrame mf=new MiFrame();
        mf.setVisible(true);
    }
    
    private class BotonActionListener implements ActionListener
    {
        public void actionPerformed(ActionEvent evt)
        { texto.setText("Accion!!");
        }
    }
}

import java.util.List;
import java.util.Collections;
import java.util.ArrayList;


public class Empresa
{
     List<Empleado> lista;
    
     public Empresa()
     {
         lista=new ArrayList<>();
     }
     
     public void addEmpleado(Empleado e)
     { lista.add(e);
     }
     
     public void listarEmpleados()
     {
         for(Empleado e:lista) System.out.println(e);
     }
     
     public double getTotalSueldos()
     {   double total=0;
         for(Empleado e:lista) total+=e.getSueldo();
         return total;
        }
        
     public void ordenarApellido()
     { Collections.sort(lista);
    }
    
    public void ordenarSueldo()
     { Collections.sort(lista,new SueldoComparator());
    }
    public void ordenarCumpleanios()
     { Collections.sort(lista,new CumpleComparator());
    }
     
}

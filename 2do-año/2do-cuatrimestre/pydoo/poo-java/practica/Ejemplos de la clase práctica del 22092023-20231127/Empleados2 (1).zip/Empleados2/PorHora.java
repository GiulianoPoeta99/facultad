
/**
 * Write a description of class PorHora here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PorHora extends Empleado
{
    private static double valorH=3000;
    private int horas;
    private int horasExtra;
    
    public PorHora(String apellido,String nombre,Fecha fCont,Fecha fCumpl,int h,int hx)
    { super(apellido,nombre,fCont,fCumpl);
      horas=h;
      horasExtra=hx;
    }
    
    public double getSueldo()
    {
        return horas*valorH+horasExtra*valorH*2;
    }
     public String toString()
    { return "Por hora "+super.toString();
    }
}

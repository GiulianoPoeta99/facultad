import java.util.Comparator;

/**
 * Write a description of class CumpleComparator here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CumpleComparator implements Comparator<Empleado>
{
    public int compare(Empleado e1,Empleado e2 )
    {  
        return e1.getFechaCumpl().compareTo(e2.getFechaCumpl());
    }
}

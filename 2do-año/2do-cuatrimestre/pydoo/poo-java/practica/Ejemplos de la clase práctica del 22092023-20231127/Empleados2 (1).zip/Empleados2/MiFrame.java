import javax.swing.JTextField;
import java.awt.Container;
import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;

public class MiFrame extends JFrame
{
    // variables de instancia, solo declaro las referencias
    JTextField ape,nom,dc,mc,ac,dn,mn,an,salario,ventas,horas,horax,art,resultado;
    JButton bJefe,bACom,bSub,bPorH,bListar;
    JPanel jpBotones,jpFContr,jpFCumple;
    JLabel lApe=new JLabel("Apellido:");//referencia inicializada en el momento de la declaracion
    JLabel lNom=new JLabel("Nombre:");
    
    Empresa empr;
    /**
     * Constructor for objects of class MiFrame
     */
    public MiFrame()
    {
        empr=new Empresa();
        //creo los objetos y los asigno a las referencias
        ape=new JTextField(20);
        nom=new JTextField(20);
        dc=new JTextField(2);
        mc=new JTextField(2);
        ac=new JTextField(4);
        dn= new JTextField(2);
        mn=new JTextField(2);
        an=new JTextField(4);
        salario=new JTextField(10);
        ventas=new JTextField(10);
        horas=new JTextField(3);
        horax=new JTextField(3);
        art=new JTextField(5);
        resultado=new JTextField(30);
        //creo paneles para organizar los componentes
        jpBotones=new JPanel();
        jpFContr=new JPanel();
        //decoro el panel con un borde con un titulo
        jpFContr.setBorder(new TitledBorder("Fecha Contratacion"));
        jpFCumple=new JPanel();
        jpFCumple.setBorder(new TitledBorder("Fecha Cumpleaños"));
        
        
        bJefe=new JButton("Jefe");
        bACom=new JButton("Comision");
        bSub=new JButton("Subordinado");
        bPorH=new JButton("Por Hora");
        bListar=new JButton("Listar");
        
        BotonAL bal=new BotonAL();//creo un ActionListener
        //agrego el mismo ActionListener (bal) a los 4 botones
        bJefe.addActionListener(bal);
        bACom.addActionListener(bal);
        bSub.addActionListener(bal);
        bPorH.addActionListener(bal);
        
        //agrego los cuatro botones a un panel
        jpBotones.add(bJefe);
        jpBotones.add(bACom);
        jpBotones.add(bSub);
        jpBotones.add(bPorH);
        
        //Obtengo el contentPane
        Container cp=this.getContentPane();
        //le digo como quiero distribuir los componentes
        cp.setLayout(new FlowLayout());
        
        //agrego los componentes
        cp.add(lApe);
        cp.add(ape);
        cp.add(lNom);
        cp.add(nom);
        
        //agrego los componentes al panel jpFContr
        jpFContr.add(new JLabel("dia:"));//creo una etiqueta y la agrego al panel, el panel va a almacenar la referencia
        jpFContr.add(dc); 
        jpFContr.add(new JLabel("mes:"));
        jpFContr.add(mc);
        jpFContr.add(new JLabel("año:"));
        jpFContr.add(ac);
        
        cp.add(jpFContr);//agrego el panel al contenedor principal
        
        //agrego los componentes al panel jpFCumple
        jpFCumple.add(new JLabel("dia:"));
        jpFCumple.add(dn);
        jpFCumple.add(new JLabel("mes:"));
        jpFCumple.add(mn);
        jpFCumple.add(new JLabel("año:"));
        jpFCumple.add(an);
        cp.add(jpFCumple);//agrego el panel al contenedor principal
        
        cp.add(new JLabel("salario:"));
        cp.add(salario);
        cp.add(new JLabel("ventas:"));
        cp.add(ventas);
        cp.add(new JLabel("horas:"));
        cp.add(horas);
        cp.add(new JLabel("horas extra:"));
        cp.add(horax);
        cp.add(new JLabel("Articulos prod.:"));
        cp.add(art);
        cp.add(jpBotones);//agrego el panel de botones
        cp.add(resultado);
        cp.add(bListar);
        bListar.addActionListener(a -> empr.listarEmpleados());
    }


    public static void main(String[] args)
    { MiFrame mf=new MiFrame();
        mf.setSize(600,250); //ancho, alto en px
        mf.setVisible(true);
    }
    
    /**
     * ActionListener implementado como clase inner
     */
    public class BotonAL implements ActionListener
    {
      public void actionPerformed(ActionEvent e)
      {
          Empleado em;
          JButton boton=(JButton)e.getSource();//obtengo el boton que fue presionado
          //leer los campos comunes a todos los empleados
          String a=ape.getText();
          String n=nom.getText();
          //...............
          //leer dma de contratacion
          //leer dma de cumpleaños
          
          //de acuerdo a que boton apretaron, leo los campos especificos del empleado
          //creo un objeto de ese tipo y muestro en el campo resultado el sueldo
          switch (boton.getText())
          { case "Jefe":// a partir de java 7 se puede utilizar String en los switch
                     //ya va por la version 17 :(
                    double s=Double.parseDouble(salario.getText() );
                    em=new Jefe(a,n,new Fecha(),new Fecha(),s);
                    empr.addEmpleado(em);
                    resultado.setText("Jefe "+em.getSueldo());
              break;
            case "Comision": 
                double sc=Double.parseDouble(salario.getText() );
                double v=Double.parseDouble(ventas.getText() );
                em=new AComision(a,n,new Fecha(),new Fecha(),sc,v);
                empr.addEmpleado(em);
                resultado.setText("a comision "+em.getSueldo());
                break; 
        case "Subordinado": 
            
               int ar=Integer.parseInt(art.getText() );
                em=new Subordinado(a,n,new Fecha(),new Fecha(),ar);
                empr.addEmpleado(em);
                resultado.setText("Subordinado "+em.getSueldo());
                
            break;
        case"Por Hora": 
        int h=Integer.parseInt(horas.getText() );
        int hx=Integer.parseInt(horax.getText() );
                em=new PorHora(a,n,new Fecha(),new Fecha(),h,hx);
                empr.addEmpleado(em);
                resultado.setText("Por Hora "+em.getSueldo());
        break;
            }
          
      }
    }
}

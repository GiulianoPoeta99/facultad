

public class Fecha implements Comparable<Fecha>
{
    int dia,mes,anio;
    
    public int compareTo(Fecha f)
    { 
        if (this.anio<f.anio) return -1;
         else if(this.anio>f.anio) return 1;
               else if (this.mes<f.mes) return -1;
                    else if(this.mes>f.mes) return 1;
                         else if(this.dia<f.dia) return -1;
                              else if(this.dia>f.dia) return 1;
                                   else return 0; 
               
    }
}


/**
 * Write a description of class AComision here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AComision extends Empleado
{
    private static double comision=3;
    private double salario;
    private double ventas;
    
    public AComision(String apellido,String nombre,Fecha fCont,Fecha fCumpl,double salario,double ventas)
    { super(apellido,nombre,fCont,fCumpl);
      this.salario=salario;
      this.ventas=ventas;
    }
    
    public double getSueldo()
    {
        return salario + (ventas * comision)/100;
    }
    
     public String toString()
    { return "A Comision "+super.toString();
    }
}

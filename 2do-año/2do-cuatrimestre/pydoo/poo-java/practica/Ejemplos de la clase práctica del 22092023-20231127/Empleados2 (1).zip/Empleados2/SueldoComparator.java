import java.util.Comparator;

/**
 * Write a description of class SueldoComparator here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SueldoComparator implements Comparator<Empleado>
{
    public int compare(Empleado e1,Empleado e2)
    { return (int)(e1.getSueldo()-e2.getSueldo());
    }
}



public class Jefe extends Empleado
{
    private double salario;
    public Jefe(String apellido,String nombre,Fecha fCont,Fecha fCumpl,double salario)
    { super(apellido,nombre,fCont,fCumpl);
        this.salario=salario;
    }
    
    public double getSueldo()
    { return salario;
    }
    
    public String toString()
    { return "Jefe "+super.toString();
    }
}
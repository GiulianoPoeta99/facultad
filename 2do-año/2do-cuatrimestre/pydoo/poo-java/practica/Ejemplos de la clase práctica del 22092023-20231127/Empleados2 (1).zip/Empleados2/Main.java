import java.util.List;
import java.util.Collections;
import java.util.ArrayList;


public class Main
{
    public static void main(String[] arg)
    {
      Empresa empr=new Empresa();

      Empleado emp= new Jefe("Bolaños","Bruce",new Fecha(),new Fecha(),70000);
      empr.addEmpleado(emp);
      empr.addEmpleado(new AComision("Gonzalez","Pedro",new Fecha(),new Fecha(),30000,100000));
      empr.addEmpleado(new Subordinado("Alvarez","Pedro",new Fecha(),new Fecha(),1000));
      empr.addEmpleado(new PorHora("Martinez","Pedro",new Fecha(),new Fecha(),160,20));
  
      System.out.println("total "+empr.getTotalSueldos());
      
      empr.ordenarApellido();
      System.out.println("");
      empr.listarEmpleados();
      
      empr.ordenarSueldo();
      System.out.println("");
      empr.listarEmpleados();
      
      
    }
}


public abstract class Empleado implements Comparable<Empleado>
{
    private String apellido,nombre;
    private Fecha fechaContr,fechaCumpl;
    
    public Empleado(String apellido,String nombre,Fecha fCont,Fecha fCumpl)
    {
        this.apellido=apellido;
        this.nombre=nombre;
        fechaContr=fCont;
        fechaCumpl=fCumpl;
    }
    
    public abstract double getSueldo();
    
    public Fecha getFechaContr()
    {
        return fechaContr;
    }
    public Fecha getFechaCumpl()
    {
        return fechaContr;
    }
    public int compareTo(Empleado e)
    {
        return this.apellido.compareTo(e.apellido);
    }
    
    public String toString()
    { return apellido+" "+nombre+" "+getSueldo();
    }
}

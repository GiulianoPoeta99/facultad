
/**
 * Write a description of class Subordinado here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Subordinado extends Empleado
{
    private static double valorArt=10;
    private int articulosProducidos;
    public Subordinado(String apellido,String nombre,Fecha fCont,Fecha fCumpl,int art)
    { super(apellido,nombre,fCont,fCumpl);
      articulosProducidos=art;  
    }
    
    public double getSueldo()
    { return articulosProducidos*valorArt;
    }
     public String toString()
    { return "Subordinado "+super.toString();
    }
}

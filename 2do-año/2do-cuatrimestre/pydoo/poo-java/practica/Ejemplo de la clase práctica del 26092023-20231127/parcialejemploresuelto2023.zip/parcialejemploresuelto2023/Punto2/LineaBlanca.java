package Punto2;

public class LineaBlanca extends Producto
{
    private double descuento=0.35;
    
    public LineaBlanca (String n, double d)
    {
        super(n,d);
        
    }
    public double getValorConDescuento()
    {
        return (super.valorProducto- (super.valorProducto*descuento));
    }
    public String toString()
    {
        return super.nombre+" "+getValorConDescuento();
    }
}

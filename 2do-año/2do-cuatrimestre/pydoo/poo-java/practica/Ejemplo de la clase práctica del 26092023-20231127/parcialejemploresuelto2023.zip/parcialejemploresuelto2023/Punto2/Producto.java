package Punto2;


public abstract class Producto implements Comparable<Producto>
{
    protected String nombre;
    protected double valorProducto;
    
    public Producto(String n,double vp)
    {
        nombre=n;
        valorProducto=vp;
    }
        
    public abstract double getValorConDescuento();
    public abstract String toString();
    
    public int compareTo(Producto p)
    {
        if (this.getValorConDescuento()<p.getValorConDescuento()) return -1;
        else if (this.getValorConDescuento()>p.getValorConDescuento()) return 1;
             else return 0;
    }
}

package Punto2;


public class Electronica extends Producto
{
    private double descuento=0.4;
    
    public Electronica (String n, double d)
    {
        super(n,d);
        
    }
    public double getValorConDescuento()
    {
        return (super.valorProducto- (super.valorProducto*descuento));
    }
    public String toString()
    {
        return super.nombre+" "+getValorConDescuento();
    }
}

package Punto2;

public class Electrodomestico extends Producto
{
    private double descuento=0.6;
    
    public Electrodomestico (String n, double d)
    {
        super(n,d);
        
    }
    public double getValorConDescuento()
    {
        return (super.valorProducto- (super.valorProducto*descuento));
    }
    public String toString()
    {
        return "Electrodomestico: "+super.nombre+" "+getValorConDescuento();
    }
}

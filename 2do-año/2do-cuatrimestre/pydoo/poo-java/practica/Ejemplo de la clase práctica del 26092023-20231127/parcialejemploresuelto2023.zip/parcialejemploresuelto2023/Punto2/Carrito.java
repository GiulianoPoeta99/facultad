package Punto2;

import java.util.*;

public class Carrito
{
    private List<Producto> lista=new ArrayList<>();
    
    public void add(Producto p)
    {
        lista.add(p);
    }
    
    public double valorTotalProductos()
    {
        double total=0;
        for (Producto i:lista) total+=i.getValorConDescuento();
        return total;
    }
    public void listar()
    {
        Collections.sort(lista);
        for (Producto i:lista) System.out.println(i);
    }
}

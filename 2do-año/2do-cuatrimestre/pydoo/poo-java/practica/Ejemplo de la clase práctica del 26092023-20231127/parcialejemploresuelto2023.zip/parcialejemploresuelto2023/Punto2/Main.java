package Punto2;


public class Main
{
    public static void main(String[] args)
    {
        Carrito c=new Carrito();
        
        c.add(new Electronica("Notebook", 60000));
        c.add(new Electronica("Tablet", 15000));
        c.add(new Electrodomestico("Tostadora", 2300));
        c.add(new LineaBlanca("Heladera", 40500));
        c.add(new LineaBlanca("Lavarropa", 25000));
        c.add(new Electrodomestico("Cafetera", 3500));
        
        System.out.println("Valor total de los productos: "+c.valorTotalProductos());
        
        c.listar();
        
    }
    
}

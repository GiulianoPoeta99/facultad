
/**
 * Write a description of class FechaTiempo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FechaTiempo
{
    private MiFecha miFecha;
    private Tiempo tiempo;
    
    public FechaTiempo(int hora,int minutos,int segundos,int dia,int mes,int anio ){
     tiempo=new Tiempo(hora,minutos,segundos);
     miFecha=new MiFecha(dia,mes,anio);
    }
    
    public String toString()
    {
       return tiempo.toString()+" "+miFecha.toString();
     }
     
     public void tick()
     {
       tiempo.tick();
       if (tiempo.getHora()==0 && tiempo.getMinutos()==0 && tiempo.getSegundos()==0)
         miFecha.incrementarDia();
    }
}

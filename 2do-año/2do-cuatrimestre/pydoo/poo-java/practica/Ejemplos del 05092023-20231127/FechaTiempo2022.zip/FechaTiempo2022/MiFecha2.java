

/**
 * Write a description of class MiFecha here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MiFecha2 extends Tiempo2
{
    // instance variables - replace the example below with your own
    //private int[] dias={}
    private int dia,mes,anio;
    
    public MiFecha2(int hora,int minutos,int segundos,int dia,int mes,int anio)
    {  super(hora,minutos,segundos);
        this.dia=dia;
        this.mes=mes;
        this.anio=anio;
    }
    
    public void incrementarDia()
    {
    }

    @Override
    public void tick()
    { super.tick();
      if (getHora()==0 && getMinutos()==0 && getSegundos()==0)
      incrementarDia();  
    }
}

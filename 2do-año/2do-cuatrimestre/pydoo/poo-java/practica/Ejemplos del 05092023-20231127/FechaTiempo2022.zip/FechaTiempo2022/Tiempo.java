
/**
 * Write a description of class Tiempo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tiempo
{
    // instance variables - replace the example below with your own
    private int hora,minutos,segundos;

    
    public Tiempo(int hora,int minutos,int segundos)
    {
        this.hora=hora;
        this.minutos=minutos;
        this.segundos=segundos;
    }

    public void tick()
    { segundos++;
      if (segundos==60)
      {incrementarMinutos();
        segundos=0;}
    }
    public void incrementarMinutos()
    { minutos++;
      if (minutos==60)
      { incrementarHora();
          minutos=0;
      }
    }
    public void incrementarHora()
    {
      hora++;
      if (hora==24) hora=0;
    }
    
    public int getHora()
    { return hora;
    }
    
    public int getMinutos()
    { return minutos;
    }
    public int getSegundos()
    { return segundos;
    }
}

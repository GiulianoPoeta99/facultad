
/**
 * Write a description of class Main here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Main
{
    public static void main(String[] args)
    { 
        Rational r1,r2,r3;
        r1=new Rational(5,3);
        r2=new Rational(2,3);
        r3=r1.sumar(r2);
        System.out.println(r3);
        System.out.println(r1.restar(r2));
        System.out.println(r1.multiplicar(r2));
        System.out.println(r1.dividir(r2));
        System.out.println(r1.flotante());
    }
}

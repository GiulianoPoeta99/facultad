
/**
 * Write a description of class Rational here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rational
{
    // instance variables - replace the example below with your own
    private int num,den;
    
    public Rational()
    { num=0;
        den=1;
    }
    
    public Rational(int num,int den)
    { this.num=num;
      this.den=den;
      simplificar();
    }
    
    public Rational sumar(Rational r)
    {
    int n=num*r.den+r.num*den;
    int d=den*r.den;
    return new Rational(n,d);
    }
    
    public Rational restar(Rational r)
    {
        int n=num*r.den-r.num*den;
    int d=den*r.den;
    return new Rational(n,d);
    }
    
    public Rational multiplicar(Rational r)
    {
        int n=num*r.num;
    int d=den*r.den;
    return new Rational(n,d);
    }
    
    public Rational dividir(Rational r)
    {
        int n=num*r.den;
    int d=den*r.num;
    return new Rational(n,d);
    }
    
    private void simplificar()
    { int mcd;
        while ((mcd=mCD(num,den))!=1)
      {
          num/=mcd;
          den/=mcd;
     }
    }
    
    public static int mCD(int a, int b) {
    if (b == 0) return a;
    return mCD(b, a % b);
}
    public double flotante()
    {  return (double)num/den;
    }
    
    public String toString()
    { return ""+num+"/"+den;
    }
}

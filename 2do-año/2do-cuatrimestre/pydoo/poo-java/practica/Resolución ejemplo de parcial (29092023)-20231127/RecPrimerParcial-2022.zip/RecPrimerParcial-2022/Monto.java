public class Monto
{
    private int monto, anterior;

    public Monto(int monto)
    {
        this.monto=monto;
    }

    public String get500()
    {
        int cant=0;
        while(monto>0)
        {
            anterior=monto;
            monto=monto-500;
            if(monto>=0)
                ++cant;

        }
        monto=anterior;
        if(cant>0)
            return "La cantidad de billetes de 500 es de: "+cant;
        else 
            return "";
    }
    
    public String get200()
    {
        int cant=0;
        while(monto>0)
        {
            anterior=monto;
            monto=monto-200;
            if(monto>=0)
                cant++;
        }
        monto=anterior;
        if(cant>0)
            return "La cantidad de billetes de 200 es de: "+cant;
        else 
            return "";
    }
    
    public String get100()
    {
        int cant=0;
        while(monto>0)
        {
            anterior=monto;
            monto=monto-100;
            if(monto>=0)
                cant++;
        }
        monto=anterior;
        if(cant>0)
            return "La cantidad de billetes de 100 es de: "+cant;
        else 
            return "";
    }
    
    public String get50()
    {
        int cant=0;
        while(monto>0)
        {
            anterior=monto;
            monto=monto-50;
            if(monto>=0)
                cant++;
        }
        monto=anterior;
        if(cant>0)
            return "La cantidad de billetes de 50 es de: "+cant;
        else 
            return "";
    }   
    
    public String get20()
    {
        int cant=0;
        while(monto>0)
        {
            anterior=monto;
            monto=monto-20;
            if(monto>=0)
                cant++;
        }
        monto=anterior;
        if(cant>0)
            return "La cantidad de billetes de 20 es de: "+cant;
        else 
            return "";
    }  
    
    public String get10()
    {
        int cant=0;
        while(monto>0)
        {
            anterior=monto;
            monto=monto-10;
            if(monto>=0)
                cant++;
        }
        monto=anterior;
        if(cant>0)
            return "La cantidad de billetes de 10 es de: "+cant;
        else 
            return "";
    } 
    
    public String get5()
    {
        int cant=0;
        while(monto>0)
        {
            anterior=monto;
            monto=monto-5;
            if(monto>=0)
                cant++;
        }
        monto=anterior;
        if(cant>0)
        return "La cantidad de billetes de 5 es de: "+cant;
        else 
            return "";
    }  
    
    public String get1()
    {
        int cant=0;
        while(monto>0)
        {
            anterior=monto;
            monto=monto-1;
            if(monto>=0)
                cant++;
        }
        monto=anterior;
        if(cant>0)
        return "La cantidad de billetes de 1 es de: "+cant;
        else 
            return "";
    }   
    
    public String get2()
    {
        int cant=0;
        while(monto>0)
        {
            anterior=monto;
            monto=monto-2;
            if(monto>=0)
                cant++;
        }
        monto=anterior;
            if(cant>0)
        return "La cantidad de billetes de 2 es de: "+cant;
                else 
            return "";
    }   
    
}

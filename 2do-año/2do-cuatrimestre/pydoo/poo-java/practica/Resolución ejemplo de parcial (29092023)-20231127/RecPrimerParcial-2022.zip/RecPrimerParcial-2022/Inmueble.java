public abstract class Inmueble implements Comparable <Inmueble>
{
    protected double precioM2,CantM2;
    
    public Inmueble(double precio, double metros2)
    {
        this.precioM2=precio;
        this.CantM2=metros2;
    }

    public abstract double precioAlquiler();
    
    public void setValorM2(double precio)
    {
        precioM2=precio;
    }
    
    public double getValorM2()
    {
        return precioM2;
    }
    
    public int compareTo(Inmueble o1)
    {
        return (int)(precioAlquiler()-o1.precioAlquiler());
    }
}

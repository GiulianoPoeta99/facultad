
public class Departamento extends Inmueble
{
    private double valorExpensas;
    
    public Departamento(double precio, double metros2, double valorExpensas)
    {
        super(precio,metros2);
        this.valorExpensas=valorExpensas;
    }

    public double precioAlquiler()
    {
        return (precioM2*CantM2)+valorExpensas;
    }
    
    public String toString()
    {
        return "El valor del Departamento es: "+precioAlquiler()+" Superficie: "+CantM2;
    }
}

import java.util.*;
public class ListInmuebles
{
    List<Inmueble> list=new ArrayList<>();
    
    public void add(Inmueble in)
    {
        list.add(in);
    }

    public void valorTotal()
    {
        int precioTotal=0;
        for (Inmueble in:list)
            precioTotal+=in.precioAlquiler();
        System.out.println("El precio total de los alquileres es: "+precioTotal);
    }
    
    public void imprimoXValor()
    {
        Collections.sort(list);
        for (Inmueble in:list)
            System.out.println(in);
    }
    
    public void imprimoXSup()
    {
        Collections.sort(list,new porSuperficie());
        for (Inmueble in:list)
            System.out.println(in);
    }
}

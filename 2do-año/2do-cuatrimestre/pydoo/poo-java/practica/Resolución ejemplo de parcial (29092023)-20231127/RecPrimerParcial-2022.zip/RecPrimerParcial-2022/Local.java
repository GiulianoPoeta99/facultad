
/**
 * Write a description of class Local here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Local extends Inmueble
{
    public Local(double precio, double cantM2)
    {
        super(precio,cantM2);
    }

    public double precioAlquiler()
    {
        return (precioM2*CantM2);
    }
    
    public String toString()
    {
        return "El valor del Local es: "+precioAlquiler()+" Superficie: "+CantM2;
    }

}

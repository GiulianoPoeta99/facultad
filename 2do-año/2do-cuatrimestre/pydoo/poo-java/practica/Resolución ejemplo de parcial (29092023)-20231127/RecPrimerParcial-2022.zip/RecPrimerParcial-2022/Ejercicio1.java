import java.util.*;
public class Ejercicio1
{
    public static void main (String args[])
    {
        System.out.println("\u000C");
        Monto mon1=new Monto(1773);
        
        System.out.println("El monto es: 1773");
        System.out.println(mon1.get500()); 
        System.out.println(mon1.get200());
        System.out.println(mon1.get100());
        System.out.println(mon1.get50());
        System.out.println(mon1.get20());
        System.out.println(mon1.get10());
        System.out.println(mon1.get5());
        System.out.println(mon1.get2());
        System.out.println(mon1.get1());
            
    }
}

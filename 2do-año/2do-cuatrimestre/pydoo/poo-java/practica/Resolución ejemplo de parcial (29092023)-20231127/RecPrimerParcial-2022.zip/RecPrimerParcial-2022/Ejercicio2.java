public class Ejercicio2
{
    public static void main(String args[])
    {
        System.out.println("\u000C");
        ListInmuebles list=new ListInmuebles();
        
        list.add(new Casa(30000,40));
        list.add(new Departamento(15000,15,50000));
        list.add(new Casa(65423,54));
        list.add(new Departamento(4363,13,675));
        list.add(new Casa(64512,54));
        list.add(new Departamento(5474,65,987));
        list.add(new Local(100000,25));
        
        list.valorTotal();
        System.out.println("----------------------");
        list.imprimoXValor();
        System.out.println("----------------------");
        list.imprimoXSup();
    }
}

public class Casa extends Inmueble
{
    private double ValorTerreno;
    
    public Casa(double precio, double metros2)
    {
        super(precio,metros2);
        ValorTerreno=precio*.5;
    }
    
    public double precioAlquiler()
    {
        return (precioM2*CantM2)+(ValorTerreno*CantM2);
    }
    
    public String toString()
    {
        return "El valor de la Casa es: "+precioAlquiler()+" Superficie: "+CantM2;
    }
}

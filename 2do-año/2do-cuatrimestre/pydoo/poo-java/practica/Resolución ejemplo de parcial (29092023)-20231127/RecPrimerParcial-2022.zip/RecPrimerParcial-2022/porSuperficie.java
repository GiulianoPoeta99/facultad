import java.util.Comparator;

/**
 * Write a description of class porSuperficie here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class porSuperficie implements Comparator<Inmueble>
{
    public int compare(Inmueble In1, Inmueble In2)
    {
        return ((int)In1.CantM2 - (int)In2.CantM2);
    }
}
